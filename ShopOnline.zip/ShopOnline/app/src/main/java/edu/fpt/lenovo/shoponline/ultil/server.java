package edu.fpt.lenovo.shoponline.ultil;

public class server {
    //https://batdongsanabc.000webhostapp.com/shoponline/getsanphammoinhat.php
    //https://batdongsanabc.000webhostapp.com/shoponline/getsanpham.php
    //https://batdongsanabc.000webhostapp.com/shoponline/getloaisp.php
    //https://batdongsanabc.000webhostapp.com/shoponline/connect.php

    public static String localhost = "https://batdongsanabc.000webhostapp.com";
    public static String Duongdanloaisp = localhost+"/shoponline/getloaisp.php";
    public static String Duongdandienthoai = localhost+"/shoponline/getsanpham.php?page=";
    public static String Duongdansanphammoinhat = localhost+"/shoponline/getsanphammoinhat.php";

}
