package edu.fpt.lenovo.shoponline.testapi;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import edu.fpt.lenovo.shoponline.R;

public class TestApiActivity extends AppCompatActivity {
    Button btnInsert, btnUpdate, btnSelect, btnDelete;
    String apiInsert = "https://batdongsanabc.000webhostapp.com/w3demo/insert.php";
    String apiUpdate = "https://batdongsanabc.000webhostapp.com/w3demo/update.php";
    String apiDelete = "https://batdongsanabc.000webhostapp.com/w3demo/delete.php";
    String apiSelect = "https://batdongsanabc.000webhostapp.com/w3demo/select.php";
    TextView txtKQ;
    //ham thuc thi api
    public void executeVolley(Context context,TextView textView,String api)
    {
        //1. Tao request
        RequestQueue queue = Volley.newRequestQueue(context);
        //2. Dua url vao request
        //StringRequest(phuongThuc,url, thanhCong,ThatBai)
        StringRequest stringRequest = new StringRequest(Request.Method.GET, api, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                textView.setText("Thanh cong: "+response.toString());
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText("Loi: "+error.getMessage());
            }
        });
        //3.Thuc thi request
        queue.add(stringRequest);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_api);
        btnInsert = findViewById(R.id.testapiBtnInsert);
        btnUpdate = findViewById(R.id.testapiBtnUpdate);
        btnDelete = findViewById(R.id.testapiBtnDelete);
        btnSelect = findViewById(R.id.testapiBtnSelect);
        txtKQ = findViewById(R.id.testapiTextView);
        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeVolley(TestApiActivity.this,txtKQ,apiInsert);
            }
        });
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeVolley(TestApiActivity.this,txtKQ,apiUpdate);
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeVolley(TestApiActivity.this,txtKQ,apiDelete);
            }
        });
        btnSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executeVolley(TestApiActivity.this,txtKQ,apiSelect);
            }
        });
    }
}
