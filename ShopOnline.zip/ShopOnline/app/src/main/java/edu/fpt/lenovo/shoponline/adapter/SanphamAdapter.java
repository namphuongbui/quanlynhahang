package edu.fpt.lenovo.shoponline.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.ArrayList;

import edu.fpt.lenovo.shoponline.R;
import edu.fpt.lenovo.shoponline.activity.ChiTietSanPham;
import edu.fpt.lenovo.shoponline.model.Sanpham;
import edu.fpt.lenovo.shoponline.ultil.CheckConnetion;

public class SanphamAdapter extends RecyclerView.Adapter<SanphamAdapter.ItemViewHolder> {
    Context context;
    ArrayList<Sanpham> sanphamArrayList;

    public SanphamAdapter(Context context, ArrayList<Sanpham> sanphamArrayList) {
        this.context = context;
        this.sanphamArrayList = sanphamArrayList;
    }

    //tao view
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sanphammoinhat,null);
        ItemViewHolder viewHolder = new ItemViewHolder(view);
        return viewHolder;
    }
    //lay du lieu
    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Sanpham sanpham = sanphamArrayList.get(position);
        holder.txttensanpham.setText(sanpham.getTensanpham());
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###");
        holder.txtgiasanpham.setText("Giá: "+decimalFormat.format(sanpham.getGiasanpham())+" VND");
        Picasso.get().load(sanpham.getHinhanhsanpham())
                .placeholder(R.drawable.home)
                .error(R.drawable.erro)
                .into(holder.imgHinhsp);
    }
    //tong so item
    @Override
    public int getItemCount() {
        return sanphamArrayList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder{
    ImageView imgHinhsp;
    TextView txttensanpham,txtgiasanpham;
    public ItemViewHolder(@NonNull View itemView) {
        super(itemView);
        imgHinhsp = itemView.findViewById(R.id.imageviewsanpham);
        txttensanpham = itemView.findViewById(R.id.textviewtensanpham);
        txtgiasanpham = itemView.findViewById(R.id.textviewgiasanpham);
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context2 = view.getContext();
                Intent intent = new Intent(context2, ChiTietSanPham.class);
                intent.putExtra("thongtinsanpham",sanphamArrayList.get(getPosition()));
                CheckConnetion.ShowToastLong(context2,sanphamArrayList.get(getPosition()).getTensanpham());
                context2.startActivity(intent);
                context.getApplicationContext().startActivity(intent);
            }
        });
    }
}
}
