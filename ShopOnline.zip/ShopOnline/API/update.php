<?php
$servername = "localhost";
$username = "id10840443_user";
$password = "12345678Aa@123";
$dbname = "id10840443_springbootdb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "UPDATE MyGuests SET lastname='Doe sau khi da cap nhat' WHERE id=10";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();
?>